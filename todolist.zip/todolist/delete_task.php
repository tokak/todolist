<?php
session_start();
require 'config.php'; 
// Oturum kontrolü
if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit;
}

// Giriş yapan kullanıcının ID'si
$user_id = $_SESSION['user_id'];

// URL'den görev ID'sini al
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $task_id = $_GET['id'];

    // Sadece kullanıcının kendi görevini sil
    $query = "DELETE FROM tasks WHERE Id = ? AND UserId = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $task_id, $user_id);
    
    if ($stmt->execute()) {
        // Başarılı silme
        header("Location: ./dashboard.php");
        exit;
    } else {
        echo "Bir hata oluştu: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Geçersiz görev ID'si.";
}

$conn->close();
?>
