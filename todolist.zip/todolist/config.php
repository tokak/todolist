<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todoappdb";

$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_set_charset($conn, "UTF8");

if (!$conn) {
    die("Bağlantı hatası: " . mysqli_connect_error());
}
?>