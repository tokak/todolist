<?php
session_start();
require 'config.php'; 

// Oturum kontrolü
if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit;
}

$fullname = $_SESSION['fullname'];
$email = $_SESSION['Email'];
$user_id = $_SESSION['user_id'];

// Bekleyen görevler
$pendingQuery = "SELECT Id, Title, Description, IsCompleted, CreatedDate 
                 FROM tasks 
                 WHERE UserId = ? AND IsCompleted = 0 AND IsActive = 1";
$stmt = $conn->prepare($pendingQuery);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$pendingTasks = $stmt->get_result();

// Tamamlanan görevler
$completedQuery = "SELECT Id, Title, Description, IsCompleted, CreatedDate 
                   FROM tasks 
                   WHERE UserId = ? AND IsCompleted = 1 AND IsActive = 1";
$stmt2 = $conn->prepare($completedQuery);
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$completedTasks = $stmt2->get_result();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Görev Paneli | <?php echo htmlspecialchars($fullname); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<?php include './partials/navbar.php'; ?>

<!-- Ana İçerik -->
<?php include './partials/taskspartial.php'; ?>

<!-- Görev Ekle Modal -->
<?php include './partials/addtaskpartial.php'; ?>

<!-- Görev Düzenleme Modal -->
<?php include './partials/updatetaskpartial.php'; ?>

<?php include './partials/scripts.php'; ?>
</body>
</html>
