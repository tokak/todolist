    <div class="container mt-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
      <h4>Görevlerim</h4>
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal">+ Yeni Görev</button>
  </div>

  <!-- Sekmeler -->
  <ul class="nav nav-tabs mb-3" id="taskTabs" role="tablist">
    <li class="nav-item" role="presentation">
      <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab">Bekleyen Görevler</button>
    </li>
    <li class="nav-item" role="presentation">
      <button class="nav-link" id="completed-tab" data-bs-toggle="tab" data-bs-target="#completed" type="button" role="tab">Tamamlanan Görevler</button>
    </li>
  </ul>

  <div class="tab-content" id="taskTabsContent">
    <!-- Bekleyen Görevler -->
    <div class="tab-pane fade show active" id="pending" role="tabpanel">
      <table class="table table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Görev Adı</th>
            <th>Açıklama</th>
            <th>Durum</th>
            <th>Tarih</th>
            <th>İşlemler</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($pendingTasks->num_rows > 0): ?>
            <?php while ($task = $pendingTasks->fetch_assoc()): ?>
              <tr>
                <td><?= $task['Id'] ?></td>
                <td><?= htmlspecialchars($task['Title']) ?></td>
                <td><?= htmlspecialchars($task['Description']) ?></td>
                <td><span class="badge bg-warning text-dark">Bekliyor</span></td>
                <td><?= date("d.m.Y H:i", strtotime($task['CreatedDate'])) ?></td>
                <td>
                  <a href="./complete_task.php?id=<?= $task['Id'] ?>" class="btn btn-sm btn-success" onclick="return confirm('Bu görevi tamamlandı olarak işaretlemek istiyor musunuz?')">Tamamla</a>
                  <a href="javascript:void(0);" class="btn btn-sm btn-outline-primary edit-btn"
                    data-id="<?= $task['Id'] ?>"
                    data-title="<?= htmlspecialchars($task['Title']) ?>"
                    data-description="<?= htmlspecialchars($task['Description']) ?>"
                    data-completed="<?= $task['IsCompleted'] ?>">Düzenle</a>
                  <a href="./delete_task.php?id=<?= $task['Id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bu görevi silmek istiyor musunuz?')">Sil</a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="6" class="text-center text-muted">Bekleyen görev bulunamadı.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Tamamlanan Görevler -->
    <div class="tab-pane fade" id="completed" role="tabpanel">
      <table class="table table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Görev Adı</th>
            <th>Açıklama</th>
            <th>Durum</th>
            <th>Tarih</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($completedTasks->num_rows > 0): ?>
            <?php while ($task = $completedTasks->fetch_assoc()): ?>
              <tr>
                <td><?= $task['Id'] ?></td>
                <td><?= htmlspecialchars($task['Title']) ?></td>
                <td><?= htmlspecialchars($task['Description']) ?></td>
                <td><span class="badge bg-success">Tamamlandı</span></td>
                <td><?= date("d.m.Y H:i", strtotime($task['CreatedDate'])) ?></td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="5" class="text-center text-muted">Tamamlanan görev bulunamadı.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>