 <div class="modal fade" id="editTaskModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        <form method="POST" action="./edit_task.php">
            <div class="modal-header">
            <h5 class="modal-title">Görevi Düzenle</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
            <input type="hidden" name="id" id="editTaskId">
            <div class="mb-3">
                <label class="form-label">Görev Başlığı</label>
                <input type="text" class="form-control" id="editTaskTitle" name="title" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Açıklama</label>
                <textarea class="form-control" id="editTaskDesc" name="description" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Durum</label>
                <select class="form-select" id="editTaskStatus" name="is_completed">
                <option value="0">Bekliyor</option>
                <option value="1">Tamamlandı</option>
                </select>
            </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
            <button type="submit" class="btn btn-primary">Güncelle</button>
            </div>
        </form>
        </div>
    </div>
</div>