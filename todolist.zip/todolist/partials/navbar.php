<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">Görev Yönetim Sistemi</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link active" href="./dashboard.php">Anasayfa</a></li>
        <li class="nav-item"><a class="nav-link text-danger" href="./logout.php">Çıkış</a></li>
      </ul>
    </div>
  </div>
</nav>