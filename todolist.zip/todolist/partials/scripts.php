<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".edit-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      document.getElementById("editTaskId").value = this.dataset.id;
      document.getElementById("editTaskTitle").value = this.dataset.title;
      document.getElementById("editTaskDesc").value = this.dataset.description;
      document.getElementById("editTaskStatus").value = this.dataset.completed;
      new bootstrap.Modal(document.getElementById("editTaskModal")).show();
    });
  });
});
</script>