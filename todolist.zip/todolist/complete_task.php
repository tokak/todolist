<?php
session_start();
require 'config.php';

// Oturum kontrolü
if (!isset($_SESSION['user_id'])) {
    header("Location: ./login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $task_id = $_GET['id'];

    // Sadece kendi görevini tamamla
    $query = "UPDATE tasks 
              SET IsCompleted = 1, UpdateDate = NOW() 
              WHERE Id = ? AND UserId = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $task_id, $user_id);

    if ($stmt->execute()) {
        header("Location: ./dashboard.php");
        exit;
    } else {
        echo "Hata oluştu: " . $conn->error;
    }
} else {
    echo "Geçersiz görev ID'si.";
}

$conn->close();
?>
