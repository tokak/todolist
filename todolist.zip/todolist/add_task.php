<?php
session_start();
require 'config.php';

// Kullanıcı girişi kontrolü
if (!isset($_SESSION["user_id"])) {
    header("Location: ./login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION["user_id"];
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);

    
    if (empty($title)) {
        $_SESSION["error"] = "Görev başlığı boş olamaz.";
        header("Location: dashboard.php");
        exit;
    }

    // Görev ekleme sorgusu
    $query = "INSERT INTO tasks (UserId, Title, Description, IsCompleted, CreatedDate, IsActive)
              VALUES (?, ?, ?, 0, NOW(), 1)";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iss", $user_id, $title, $description);

    if ($stmt->execute()) {
        $_SESSION["success"] = "Görev başarıyla eklendi.";
    } else {
        $_SESSION["error"] = "Görev eklenirken hata oluştu: " . $stmt->error;
    }

    $stmt->close();
    header("Location: ./dashboard.php");
    exit;
} else {
    header("Location: ./dashboard.php");
    exit;
}
?>
