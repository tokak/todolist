  <?php include("config.php"); ?> 
  <?php
  $message = "";
  if (isset($_POST["save"])) {

      $fullname = $_POST["NameSurname"];
      $email = $_POST["Email"];
      $password = $_POST["Password"];
      $confirmPassword = $_POST["ConfirmPassword"];

      if (empty($fullname) || empty($email) || empty($password) || empty($confirmPassword)) {
          $message = "Lütfen tüm alanları doldurun.";
      } elseif ($password !== $confirmPassword) {
          $message = "Şifreler eşleşmiyor.";
      } else {
          
          $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

          // Hazırlanmış SQL sorgusu kullan
          $sql = "INSERT INTO users (NameSurname, Email, PasswordHash,CreatedDate,IsActive) VALUES ('$fullname', '$email', '$hashedPassword',Now(),1)";

          $sqlexecute = mysqli_query($conn, $sql);      

          if ($sqlexecute) {
             
             echo "<script>                   
                    window.location.href = '/todolist/login.php';
                  </script>";
            exit;
          } else {
              $message = "Bir hata oluştu: " . mysqli_error($conn);
          }

          mysqli_close($conn);
      }
  }
  ?>
  <!DOCTYPE html>
  <html lang="tr">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Görev Yönetim Paneli Kayıt İşlemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
     <style>
        body {
            background: #f8f9fa;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-card {
            max-width: 420px;
            width: 100%;
            padding: 2rem;
            background: #fff;
            border-radius: 1rem;
            box-shadow: 0 4px 25px rgba(0,0,0,0.1);
        }
    </style>

</head>
  <body>

    <div class="register-card">
      <h3 class="text-center mb-4 text-primary">Görev Yönetim Sistemi</h3>
      <h5 class="text-center mb-4">Kayıt Ol</h5>

      <form action="register.php" method="post">

      <?php if (!empty($message)): ?>
      <div class="alert alert-warning" role="alert">
          <?php echo $message; ?>
      </div>
      <?php endif; ?>

        <div class="mb-3">
          <label for="fullname" class="form-label">Ad Soyad</label>
          <input type="text" class="form-control" id="fullname" name="NameSurname" placeholder="Ad Soyadınızı girin">
        </div>

        <div class="mb-3">
          <label for="email" class="form-label">E-Posta</label>
          <input type="email" class="form-control" id="email" name="Email" placeholder="E-posta adresinizi girin">
        </div>

        <div class="mb-3">
          <label for="password" class="form-label">Şifre</label>
          <input type="password" class="form-control" id="password" name="Password" placeholder="Şifrenizi girin">
        </div>

        <div class="mb-3">
          <label for="confirmPassword" class="form-label">Şifre Tekrar</label>
          <input type="password" class="form-control" id="confirmPassword" name="ConfirmPassword" placeholder="Şifrenizi tekrar girin">
        </div>

        <button type="submit" name="save" class="btn btn-primary w-100">Kayıt Ol</button>

        <p class="text-center mt-3 mb-0">
          Zaten bir hesabınız var mı? 
          <a href="/todolist/login.php" class="text-decoration-none">Giriş yapın</a>
        </p>
      </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
  </html>
