<?php
require 'config.php'; 
session_start();
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['Email']) ? trim($_POST['Email']) : '';
    $password = isset($_POST['Password']) ? $_POST['Password'] : '';

    if (empty($email) || empty($password)) {
        $message = "E-posta ve şifre gerekli.";
    } else {
      
        $stmt = mysqli_prepare($conn, "SELECT id, Email, PasswordHash, NameSurname FROM users WHERE Email = ? LIMIT 1");
        if (!$stmt) {
            die("sql hatası: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $id, $emailDb, $hashFromDb, $fullname);
        if (mysqli_stmt_fetch($stmt)) {
           
            if (password_verify($password, $hashFromDb)) {                
                session_regenerate_id(true);
                $_SESSION['user_id'] = $id;
                $_SESSION['Email'] = $emailDb;
                $_SESSION['fullname'] = $fullname;

                mysqli_stmt_close($stmt);
                header("Location: ./dashboard.php");
                exit;
            } else {
               
                $message = "E-posta veya şifre hatalı.";
            }
        } else {
           
            $message = "E-posta veya şifre hatalı.";
        }

        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap | Görev Yönetim Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Görev Yönetim Sistemi</h3>

                    <?php if($message != ""): ?>
                        <div class="alert alert-warning text-center py-2"><?php echo $message; ?></div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">E-posta</label>
                            <input type="email" name="Email" class="form-control" placeholder="E-posta adresinizi girin" >
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Şifre</label>
                            <input type="password" name="Password" class="form-control" placeholder="Şifrenizi girin" >
                        </div>
                        <div class="d-grid">
                            <button type="submit" name="login" class="btn btn-primary">Giriş Yap</button>
                        </div>
                    </form>

                    <p class="text-center mt-3">
                        Henüz hesabınız yok mu?
                        <a href="register.php" class="text-decoration-none">Kayıt olun</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
